// Toggle da sidebar
function toggleMenu() {
    const sidebar = document.querySelector('.sidebar');
    sidebar.classList.toggle('open');
}

// Dados dos pratos
const dados = {
    3: { titulo: "Sanduíche de Atum", porcoes: "Refeição prática", imagem: "/assets/img/sanduiche.jpg", ingredientes: ["Pão de Forma", "Atum em conserva", "Maionese", "Alface", "Tomate", "Sal", "Pimenta do reino",] },
    4: { titulo: "Wrap de Frango", porcoes: "Refeição prática", imagem: "/assets/img/wrap-de-frango.jpg", ingredientes: ["Tortilha de trigo", "Frango desfiado (cozido ou grelhado", "Alface Americana", "Cenoura ralada", "Cream Cheese ou Requeijão"] },
    5: { titulo: "Pão de Quiejo Recheado", porcoes: "Refeição prática", imagem: "/assets/img/paodequeijo.jpg", ingredientes: ["Pão de queijo pronto (ou caseiro)", "Queijo Mussarela", "Presunto",] },
    6: { titulo: "Tapioca de Banana e Canela", porcoes: "Refeição caseira", imagem: "/assets/img/tapioca.jpg", ingredientes: ["Goma de tapioca", "Banana fatiada", "Canela em pó", "Mel (opcional)",] },
    7: { titulo: "Mini Pizza de Pão", porcoes: "Refeição caseira", imagem: "/assets/img/mini-pizza.jpg", ingredientes: ["Pão Francês (ou de Forma)", "Molho de Tomate ( ou Extrato de Tomate)", "Queijo Ralado", "Presunto ( ou calabresa)", "Orégano",] },
    8: { titulo: "Omelete no Pão", porcoes: "Refeição caseira", imagem: "/assets/img/paocomomelete.jpg", ingredientes: ["Ovos de Galinha (ou Galinha Caipira)", "Queijo", "Tomate picado", "Cebola picada", "Pão de Forma ( ou Francês)",] },
    9: { titulo: "Salada no Pote", porcoes: "Refeição saudável", imagem: "/assets/img/saladanopote.jpg", ingredientes: ["Alface", "Tomate-cereja", "Frango Grelhado em cubos", "Grão-de-bico", "Cenoura ralada",] },
    10: { titulo: "Bruschetta Simples", porcoes: "Refeição caseira", imagem: "/assets/img/bruschetta.jpg", ingredientes: ["Pão Italiano", "Tomate picado", "Manjericão", "Azeite de Oliva", "Alho",] },
    11: { titulo: "Iogurte Natural ou Grego", porcoes: "Refeição saudável", imagem: "/assets/img/iogurte.jpg", ingredientes: ["Iogurte Natural ( ou Grego)", "Frutas picadas como", "Banana", "Morango", "Maçã, etc",] },
    12: { titulo: "Cuscuz Nordestino", porcoes: "Refeição prática", imagem: "/assets/img/cuscuz.jpg", ingredientes: ["Flocos de milho para Cuscuz", "Sal a gosto", "Água", "Tipos de Recheio", "Queijo coalho ( ou Mussarela)", "Ovo", "Manteiga ( ou Margarina, etc)",] }
};

const container = document.getElementById('cardsContainer');

// Gera os cards
function gerarCards() {
    for (let id in dados) {
        const prato = dados[id];
        const card = document.createElement('div');
        card.classList.add('col-md-4');
        card.innerHTML = `
          <div class="card text-center">
            <img src="${prato.imagem}" alt="${prato.titulo}">
            <div class="card-content">
              <h2>${prato.titulo}</h2>
              <p>${prato.porcoes}</p>
              <button class="btn btn-card" onclick="abrirPopup(${id})">Ver mais</button>
            </div>
          </div>
        `;
        container.appendChild(card);
    }
}

// Abre popup
function abrirPopup(id) {
    const prato = dados[id];
    const lista = prato.ingredientes.map(item => `<li>${item}</li>`).join('');
    const popup = document.createElement('div');
    popup.classList.add('popup', 'active');
    popup.innerHTML = `
        <div class="popup-content">
          <button class="close-btn" onclick="fecharPopup(this)">×</button>
          <h2>${prato.titulo}</h2>
          <p><strong>Ingredientes:</strong></p>
          <ul>${lista}</ul>
        </div>
      `;
    popup.addEventListener('click', (e) => { if (e.target === popup) popup.remove(); });
    document.body.appendChild(popup);
}

function fecharPopup(btn) {
    const popup = btn.closest('.popup');
    popup.remove();
}

document.addEventListener('keydown', (e) => {
    if (e.key === "Escape") {
        const popup = document.querySelector('.popup.active');
        if (popup) popup.remove();
    }
});

window.addEventListener('DOMContentLoaded', gerarCards);
